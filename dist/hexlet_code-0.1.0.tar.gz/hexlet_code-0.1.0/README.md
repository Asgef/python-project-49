### Hexlet tests and linter status:
[![Actions Status](https://github.com/Asgef/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Asgef/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/37841a9ac18f02fa38d3/maintainability)](https://codeclimate.com/github/Asgef/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/37841a9ac18f02fa38d3/test_coverage)](https://codeclimate.com/github/Asgef/python-project-49/test_coverage)

### Gameplay for 'brain-venv'
[![asciicast](https://asciinema.org/a/jobYKaRqmmtC6MngRJxn4E8vR.svg)](https://asciinema.org/a/jobYKaRqmmtC6MngRJxn4E8vR)

### Gameplay for 'brain-calc'
[![asciicast](https://asciinema.org/a/GfzD8aQoJnEhcSMBK9vQABYE1.svg)](https://asciinema.org/a/GfzD8aQoJnEhcSMBK9vQABYE1)

### Gameplay for 'brain-gcd'
[![asciicast](https://asciinema.org/a/kZzUP66qaYzfAS3Axs5vjdjTf.svg)](https://asciinema.org/a/kZzUP66qaYzfAS3Axs5vjdjTf)

### Gameplay for 'brain-progression'
[![asciicast](https://asciinema.org/a/mB5PElHqBExxOYGXXzkK8YLv7.svg)](https://asciinema.org/a/mB5PElHqBExxOYGXXzkK8YLv7)
